    
    <?php $__env->startSection('content'); ?>
        <?php
            $rec = \DB::table('tblmhs')
                ->where('id', $id)
                ->first();
                $dataDosenPA = DB::Table('tbldosen')->get();
                $dataProdi = DB::Table('prodi')->get();
        ?>
        <section class="content">
            <div class="container-fluid">
                <div class="row mt-4">
                    <!-- left column -->
                    <div class="col-12">
                        <!-- general form elements -->
                        <div class="card card-primary">
                            <div class="card-header">
                                <h3 class="card-title">Edit Mahasiswaa</h3>
                            </div>
                            <!-- /.card-header -->
                            <!-- form start -->
                            <form action="<?php echo e(url('mahasiswa/' . $id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <input type="hidden" name="id" value="<?php echo e($id); ?>">
                                <div class="card-body">
                                    <div class="form-group">
                                        <label for="nim">NIM</label>
                                        <input type="number" class="form-control" id="nim" name="nim"
                                            value="<?php echo e($rec->nim ?? ''); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="nama">Nama Mahasiswa</label>
                                        <input type="text" class="form-control" id="nama" name="nama"
                                            value="<?php echo e($rec->nama ?? ''); ?>">
                                    </div>
                                    <div class="form-group d-flex flex-column">
                                        <label for="jenis_kelamin">Jenis Kelamin</label>
                                        <div class="icheck-primary d-inline">
                                            <input type="radio" id="radioPrimary1 jenis_kelamin" name="jenis_kelamin"
                                                value="laki-laki" <?php echo e($rec->jenis_kelamin == 'laki-laki' ? 'checked' : ''); ?>>
                                            <label for="radioPrimary1">
                                                Laki-Laki
                                            </label>
                                        </div>
                                        <div class="icheck-primary d-inline">
                                            <input type="radio" id="radioPrimary1 jenis_kelamin" name="jenis_kelamin"
                                                value="perempuan" <?php echo e($rec->jenis_kelamin == 'perempuan' ? 'checked' : ''); ?>>
                                            <label for="radioPrimary1">
                                                Perempuan
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="alamat">Alamat</label>
                                        <input type="text" class="form-control" id="alamat" name="alamat"
                                            value="<?php echo e($rec->alamat ?? ''); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="nohp">No Telepon</label>
                                        <input type="number" class="form-control" id="nohp" name="nohp"
                                            value="<?php echo e($rec->nohp ?? ''); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="id_prodi=">Prodi</label>
                                        <select class="form-control select2" style="width: 100%;" name="id_prodi"
                                            id="id_prodi" required>
                                            <?php $__currentLoopData = $dataProdi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prodi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($prodi->id_prodi); ?>"
                                                    <?php echo e($rec->id_prodi == $prodi->id_prodi ? 'selected' : ''); ?>>
                                                    <?php echo e($prodi->nama_prodi); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="id_dosen=">Nama Dosen PA</label>
                                        <select class="form-control select2" style="width: 100%;" name="id_dosen"
                                            id="id_dosen" required>
                                            <?php $__currentLoopData = $dataDosenPA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosenPA): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($dosenPA->id_dosen); ?>"
                                                    <?php echo e($rec->id_dosen == $dosenPA->id_dosen ? 'selected' : ''); ?>>
                                                    <?php echo e($dosenPA->nama_dosen); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <!-- /.card-body -->

                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!--/.col (right) -->
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('include.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\learn-laravel\resources\views/mahasiswa/edit.blade.php ENDPATH**/ ?>