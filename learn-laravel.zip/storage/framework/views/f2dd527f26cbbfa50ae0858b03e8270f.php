    
    <?php $__env->startSection('content'); ?>

    <?php if(session('sukses')): ?>
    <div class="alert alert-dismissible fade show alert-success" role="alert">
        <strong>Halo, User!</strong> <?php echo e(session('sukses')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif; ?>
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Data Kelas</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">Data Kelas</li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">DataTable with minimal features & hover style</h3>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <table id="example2" class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Kode Kelas</th>
                                            <th>Nama Kelas</th>
                                            <th>Tahun Akademik</th>
                                            <th>Edit</th>
                                            <th>Delete</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $recordKelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($no++); ?></td>
                                                <td><?php echo e($record->kode_kelas ?? '-'); ?></td>
                                                <td><?php echo e($record->nama_kelas ?? '-'); ?></td>
                                                <td><?php echo e($record->kode_tahun_akademik); ?> - <?php echo e($record->nama_tahun_akademik); ?></td>
                                                <td><a href="<?php echo e(Route('kelas.edit', $record->id_kelas)); ?>"
                                                        class="btn btn-primary">Edit</a></td>
                                                <td>
                                                    <form action="<?php echo e(Route('kelas.destroy', $record->id_kelas)); ?>"
                                                        method="POST" onsubmit="return confirm('Yakin Ingin Menghapus ?')">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-danger">Delete</button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <div class="d-flex justify-content-between mt-3">
                                    <a href="<?php echo e(url('/')); ?>" class="btn btn-danger">Kembali</a>
                                    <a href="<?php echo e(url('kelas/create')); ?>" class="btn btn-primary">Tambah Data</a>
                                </div>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('include.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\learn-laravel\resources\views/kelas/list.blade.php ENDPATH**/ ?>